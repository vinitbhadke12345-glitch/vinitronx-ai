# VINITRONX AI 🚀

**BUILD. EARN. AUTOMATE WITH AI**

India's #1 All-in-One AI Platform powered by Claude & Gemini.
Made by **Vinit Vijay Bhadke** — Maharashtra, India.

---

## ⚡ Quick Start (Local)

```bash
# 1. Install
npm install

# 2. API Key setup
cp .env.example .env.local
# .env.local mein CLAUDE_API_KEY daalo

# 3. Run
npm run dev
# http://localhost:3000 kholo
```

---

## 🌐 Deploy on Vercel (Free)

1. GitHub pe push karo
2. https://vercel.com mein import karo
3. Environment variable add karo: `CLAUDE_API_KEY`
4. Deploy! ✅

---

## 📱 4 Pages

| Page | Description |
|------|-------------|
| 🏠 Home | Landing page with stats & CTAs |
| 💬 Chat | Claude AI + Demo mode chat |
| 🛠️ Features | All 8 features + tech stack |
| 👤 About | Vinit's profile + contact |

---

Made with ❤️ by Vinit Vijay Bhadke
