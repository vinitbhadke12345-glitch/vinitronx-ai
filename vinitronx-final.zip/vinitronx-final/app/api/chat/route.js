import { NextResponse } from "next/server"

export async function POST(req) {
  try {
    const { prompt, model } = await req.json()
    if (!prompt?.trim()) return NextResponse.json({ error: "Prompt empty hai!" }, { status: 400 })

    // Demo mode
    if (model === "demo") {
      const q = prompt.toLowerCase()
      let text = ""
      if (q.includes("hello") || q.includes("hi") || q.includes("namaste"))
        text = "👋 Namaste! Main VINITRONX AI hoon — India ka #1 AI Platform! Claude mode try karo real AI ke liye! 🚀"
      else if (q.includes("vinitronx"))
        text = "⚡ VINITRONX AI — Build. Earn. Automate with AI. Maharashtra se poori duniya mein! 🌍"
      else if (q.includes("vinit") || q.includes("who") || q.includes("kisne"))
        text = "👨‍💻 Banaya hai Vinit Vijay Bhadke ne — passionate AI developer, freelancer, aur VINITRONX ka founder!"
      else if (q.includes("feature") || q.includes("kya"))
        text = "🛠️ Claude AI, Gemini, Demo mode, lightning fast, secure, mobile-ready — sab kuch ek jagah!"
      else
        text = `🎮 Demo: "${prompt}" — Real AI ke liye Claude mode select karo! 💡`
      return NextResponse.json({ response: text, model: "demo" })
    }

    // Claude mode
    const apiKey = process.env.CLAUDE_API_KEY
    if (!apiKey) return NextResponse.json({ error: "CLAUDE_API_KEY not set in .env.local" }, { status: 400 })

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 1024,
        system: "You are VINITRONX AI, a smart assistant created by Vinit Vijay Bhadke from Maharashtra, India. Platform tagline: Build. Earn. Automate with AI. Reply in Hinglish (Hindi + English mix) unless user writes pure English. Be helpful, friendly, and concise.",
        messages: [{ role: "user", content: prompt }],
      }),
    })

    const data = await res.json()
    if (!res.ok) return NextResponse.json({ error: data.error?.message || "Claude API error" }, { status: res.status })

    return NextResponse.json({ response: data.content?.[0]?.text || "No response", model: "claude" })
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
