"use client"
import { useState, useRef, useEffect } from "react"
import Image from "next/image"

// ── CONSTANTS ───────────────────────────────────────────────────────────
const STATS = [
  { val: "10M+", lbl: "AI Requests" },
  { val: "50K+", lbl: "Users Global" },
  { val: "99.9%", lbl: "Uptime" },
  { val: "#1",   lbl: "India AI Platform" },
]

const FEATURES = [
  { icon:"🧠", title:"Claude AI",       color:"#00f5ff", badge:"ANTHROPIC",    desc:"Anthropic ka most powerful AI — code, writing, analysis, Q&A sab kuch ek jagah." },
  { icon:"✨", title:"Gemini AI",        color:"#4285f4", badge:"GOOGLE",       desc:"Google Gemini — multimodal, fast, aur up-to-date knowledge ke saath." },
  { icon:"🎮", title:"Demo Mode",        color:"#00ff88", badge:"FREE",         desc:"Koi API key nahi chahiye. Instantly try karo — zero setup, zero cost." },
  { icon:"⚡", title:"Lightning Fast",   color:"#ffcc00", badge:"SPEED",        desc:"FastAPI powered backend — millisecond response times. Pure speed." },
  { icon:"🔒", title:"Secure & Private", color:"#ff0080", badge:"ENCRYPTED",    desc:"End-to-end encrypted. Conversations kabhi store ya share nahi hoti." },
  { icon:"📱", title:"Mobile Ready",     color:"#bf00ff", badge:"RESPONSIVE",   desc:"Phone, tablet, desktop — sab pe perfect cyberpunk experience." },
  { icon:"🌐", title:"Hinglish Support", color:"#ff8c00", badge:"MULTILINGUAL", desc:"Hindi, English ya Hinglish — AI samjhega aur jawab dega." },
  { icon:"🚀", title:"Production Ready", color:"#00f5ff", badge:"DEPLOYED",     desc:"Vercel + Railway deploy — enterprise-grade infra with CI/CD." },
]

const TECHSTACK = [
  ["⚛️","React/Next.js","#00f5ff"],["🐍","FastAPI Python","#bf00ff"],
  ["🧠","Claude API","#00f5ff"],["✨","Gemini API","#4285f4"],
  ["🎨","TailwindCSS","#ff0080"],["🗄️","MongoDB","#00ff88"],
  ["☁️","Vercel","#ffffff"],["🚂","Railway","#bf00ff"],
]

const SKILLS = ["Claude API","Gemini AI","React","Next.js","FastAPI","Node.js","MongoDB","TailwindCSS","Python","AI Products","Freelancing","UI/UX"]

const C = {
  cyan:"#00f5ff", purple:"#bf00ff", green:"#00ff88",
  pink:"#ff0080", bg:"#020408",
  card:"rgba(4,11,26,0.88)", border:"rgba(0,245,255,0.11)",
  text:"#ddeeff", muted:"rgba(180,210,255,0.5)",
}

// ── SHARED COMPONENTS ───────────────────────────────────────────────────
function Bg() {
  return (
    <>
      <div style={{position:"fixed",width:600,height:600,borderRadius:"50%",background:"#bf00ff",filter:"blur(150px)",opacity:.09,top:-200,left:-150,pointerEvents:"none",zIndex:0}}/>
      <div style={{position:"fixed",width:500,height:500,borderRadius:"50%",background:"#00f5ff",filter:"blur(150px)",opacity:.07,bottom:-150,right:-100,pointerEvents:"none",zIndex:0}}/>
      <div style={{position:"fixed",width:300,height:300,borderRadius:"50%",background:"#ff0080",filter:"blur(120px)",opacity:.04,top:"40%",left:"45%",pointerEvents:"none",zIndex:0}}/>
      <div style={{position:"fixed",inset:0,backgroundImage:"linear-gradient(rgba(0,245,255,0.022) 1px,transparent 1px),linear-gradient(90deg,rgba(0,245,255,0.022) 1px,transparent 1px)",backgroundSize:"44px 44px",pointerEvents:"none",zIndex:0}}/>
    </>
  )
}

function Card({ children, color = C.border, style = {} }) {
  return (
    <div style={{background:C.card,border:`1px solid ${color}`,borderRadius:18,backdropFilter:"blur(14px)",...style}}>
      {children}
    </div>
  )
}

function NeonBtn({ children, onClick, variant="cyan", style={} }) {
  const [h,setH]=useState(false)
  const colors={cyan:C.cyan,purple:C.purple,green:C.green}
  const col=colors[variant]||C.cyan
  return (
    <button
      onClick={onClick}
      onMouseEnter={()=>setH(true)}
      onMouseLeave={()=>setH(false)}
      style={{background:h?`linear-gradient(135deg,${col},${C.purple})`:"transparent",border:`2px solid ${col}`,color:h?"#000":col,fontFamily:"Orbitron,monospace",fontSize:12,fontWeight:700,letterSpacing:2,padding:"14px 36px",borderRadius:12,cursor:"pointer",boxShadow:h?`0 0 40px ${col}66`:`0 0 15px ${col}22`,transition:"all 0.3s",...style}}
    >{children}</button>
  )
}

// ── TOP NAV ─────────────────────────────────────────────────────────────
function TopNav({ tab, setTab }) {
  const NAV=[{k:"home",i:"🏠",l:"HOME"},{k:"chat",i:"💬",l:"CHAT"},{k:"features",i:"🛠️",l:"FEATURES"},{k:"about",i:"👤",l:"ABOUT"}]
  return (
    <nav style={{display:"flex",alignItems:"center",gap:10,padding:"12px 20px",borderBottom:`1px solid ${C.border}`,background:"rgba(2,4,8,0.94)",backdropFilter:"blur(20px)",position:"sticky",top:0,zIndex:50,flexWrap:"wrap"}}>
      <Image src="/logo.png" alt="VINITRONX" width={36} height={36} style={{objectFit:"contain",cursor:"pointer",filter:"drop-shadow(0 0 8px rgba(0,245,255,0.6))"}} onClick={()=>setTab("home")}/>
      <span onClick={()=>setTab("home")} style={{fontFamily:"Orbitron,monospace",fontSize:"clamp(13px,2.5vw,18px)",fontWeight:900,color:C.cyan,letterSpacing:2,cursor:"pointer",textShadow:`0 0 14px ${C.cyan}`}}>VINITRONX AI</span>
      <div style={{width:7,height:7,borderRadius:"50%",background:C.green,boxShadow:`0 0 8px ${C.green}`,animation:"pulse 2s infinite"}}/>
      <div style={{marginLeft:"auto",display:"flex",gap:4,flexWrap:"wrap"}}>
        {NAV.map(n=>(
          <button key={n.k} onClick={()=>setTab(n.k)} style={{background:tab===n.k?"rgba(0,245,255,0.09)":"transparent",border:`1px solid ${tab===n.k?"rgba(0,245,255,0.35)":"transparent"}`,color:tab===n.k?C.cyan:"rgba(255,255,255,0.32)",fontFamily:"Orbitron,monospace",fontSize:"clamp(8px,1.5vw,10px)",letterSpacing:1.5,padding:"7px 13px",borderRadius:8,cursor:"pointer",transition:"all 0.2s"}}>
            {n.i} {n.l}
          </button>
        ))}
      </div>
    </nav>
  )
}

// ── PAGE 1: HOME ─────────────────────────────────────────────────────────
function HomePage({ setTab }) {
  return (
    <div style={{minHeight:"calc(100vh - 62px)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"40px 20px",position:"relative",zIndex:1,textAlign:"center"}}>

      {/* Logo */}
      <div style={{position:"relative",marginBottom:16}}>
        <div style={{position:"absolute",inset:"-28px",borderRadius:"50%",background:"radial-gradient(circle,rgba(0,245,255,0.2),transparent 70%)",animation:"glow 3s ease-in-out infinite",zIndex:0,pointerEvents:"none"}}/>
        <Image src="/logo.png" alt="VINITRONX AI" width={220} height={220}
          style={{objectFit:"contain",filter:"drop-shadow(0 0 36px rgba(0,245,255,0.6))",position:"relative",zIndex:1,width:"clamp(150px,32vw,220px)",height:"clamp(150px,32vw,220px)"}}/>
      </div>

      <p style={{fontFamily:"Orbitron,monospace",fontSize:"clamp(10px,2vw,13px)",color:"rgba(0,245,255,0.45)",letterSpacing:6,marginBottom:6}}>ALL-IN-ONE AI PLATFORM</p>
      <p style={{fontFamily:"Orbitron,monospace",fontSize:"clamp(11px,2vw,14px)",color:C.purple,letterSpacing:4,marginBottom:36,textShadow:`0 0 20px ${C.purple}`}}>BUILD. EARN. AUTOMATE WITH AI</p>

      {/* Stats */}
      <div style={{display:"flex",gap:"clamp(20px,4vw,56px)",flexWrap:"wrap",justifyContent:"center",marginBottom:40}}>
        {STATS.map(s=>(
          <div key={s.lbl} style={{textAlign:"center"}}>
            <div style={{fontFamily:"Orbitron,monospace",fontSize:"clamp(22px,5vw,38px)",fontWeight:900,background:"linear-gradient(135deg,#00f5ff,#bf00ff)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>{s.val}</div>
            <div style={{fontFamily:"Orbitron,monospace",fontSize:9,color:"rgba(255,255,255,0.28)",letterSpacing:2,marginTop:3}}>{s.lbl}</div>
          </div>
        ))}
      </div>

      {/* Pills */}
      <div style={{display:"flex",gap:10,flexWrap:"wrap",justifyContent:"center",marginBottom:40}}>
        {["⚡ Real Claude AI","🎨 Cyberpunk UI","🌐 Hinglish","🆓 Free Demo","📱 Mobile Ready"].map(f=>(
          <div key={f} style={{padding:"8px 18px",background:"rgba(0,245,255,0.05)",border:`1px solid ${C.border}`,borderRadius:24,fontFamily:"Orbitron,monospace",fontSize:10,color:"rgba(0,245,255,0.65)",letterSpacing:1}}>{f}</div>
        ))}
      </div>

      {/* CTAs */}
      <div style={{display:"flex",gap:16,flexWrap:"wrap",justifyContent:"center",marginBottom:52}}>
        <NeonBtn onClick={()=>setTab("chat")}>START CHATTING ▶</NeonBtn>
        <NeonBtn onClick={()=>setTab("features")} variant="purple">FEATURES ✦</NeonBtn>
      </div>

      {/* Creator */}
      <Card style={{display:"flex",alignItems:"center",gap:14,padding:"14px 26px",borderRadius:50}}>
        <Image src="/photo.webp" alt="Vinit" width={42} height={42} style={{borderRadius:"50%",objectFit:"cover",border:"2px solid rgba(0,245,255,0.4)"}}/>
        <div style={{textAlign:"left"}}>
          <div style={{fontFamily:"Orbitron,monospace",fontSize:9,color:"rgba(0,245,255,0.45)",letterSpacing:2}}>CREATED BY</div>
          <div style={{fontFamily:"Orbitron,monospace",fontSize:12,color:C.cyan,fontWeight:700}}>Vinit Vijay Bhadke</div>
        </div>
        <div style={{fontFamily:"Orbitron,monospace",fontSize:9,color:C.green,border:`1px solid ${C.green}`,padding:"3px 11px",borderRadius:16,letterSpacing:1,marginLeft:6}}>🇮🇳 INDIA</div>
      </Card>

    </div>
  )
}

// ── PAGE 2: CHAT ─────────────────────────────────────────────────────────
function ChatPage() {
  const [msgs, setMsgs] = useState([{
    role:"ai", model:"system",
    content:"⚡ VINITRONX AI — Online!\n\nNamaste! Koi bhi sawaal pucho.\n🧠 Claude = Real AI  |  🎮 Demo = Free\n\nMain ready hoon! 🚀"
  }])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [model, setModel] = useState("demo")
  const ref = useRef(null)

  useEffect(() => { ref.current?.scrollIntoView({ behavior:"smooth" }) }, [msgs, loading])

  const MS = {
    claude: { label:"🧠 Claude", color:C.cyan,  tag:"ANTHROPIC" },
    demo:   { label:"🎮 Demo",   color:C.green, tag:"FREE MODE" },
  }
  const cfg = MS[model]

  const send = async () => {
    const p = input.trim()
    if (!p || loading) return
    setInput(""); setLoading(true)
    setMsgs(m => [...m, { role:"user", content:p }])
    try {
      const res = await fetch("/api/chat", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ prompt:p, model })
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || "Error")
      setMsgs(m => [...m, { role:"ai", model, content:d.response }])
    } catch(e) {
      setMsgs(m => [...m, { role:"ai", model:"error", content:`❌ ${e.message}\n\nDemo mode try karo!` }])
    }
    setLoading(false)
  }

  return (
    <div style={{display:"flex",flexDirection:"column",height:"calc(100vh - 62px)"}}>

      {/* Toolbar */}
      <div style={{padding:"10px 18px",display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",borderBottom:`1px solid ${C.border}`,background:"rgba(2,4,8,0.7)",backdropFilter:"blur(10px)"}}>
        {Object.entries(MS).map(([k,m])=>(
          <button key={k} onClick={()=>setModel(k)} style={{background:model===k?`${m.color}16`:"transparent",border:`1px solid ${model===k?m.color:"rgba(255,255,255,0.1)"}`,color:model===k?m.color:"rgba(255,255,255,0.3)",fontFamily:"Orbitron,monospace",fontSize:10,letterSpacing:1,padding:"8px 18px",borderRadius:9,cursor:"pointer",boxShadow:model===k?`0 0 16px ${m.color}44`:"none",transition:"all 0.2s"}}>
            {m.label}
          </button>
        ))}
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:7}}>
          <div style={{width:7,height:7,borderRadius:"50%",background:cfg.color,boxShadow:`0 0 8px ${cfg.color}`}}/>
          <span style={{fontFamily:"Orbitron,monospace",fontSize:9,color:cfg.color,letterSpacing:2}}>{cfg.tag}</span>
        </div>
        <button onClick={()=>setMsgs([{role:"ai",model:"system",content:"🗑️ Chat cleared! Fresh start karo."}])}
          style={{background:"transparent",border:"1px solid rgba(255,50,50,0.2)",color:"rgba(255,80,80,0.5)",fontFamily:"Orbitron,monospace",fontSize:8,padding:"5px 12px",borderRadius:6,cursor:"pointer",letterSpacing:1}}>
          CLEAR
        </button>
      </div>

      {/* Messages */}
      <div style={{flex:1,overflowY:"auto",padding:"18px 16px",display:"flex",flexDirection:"column",gap:16}}>
        {msgs.map((m,i)=>(
          <div key={i} className="fade-up" style={{display:"flex",flexDirection:"column",alignItems:m.role==="user"?"flex-end":"flex-start"}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
              {m.role!=="user" && <Image src="/logo.png" alt="" width={22} height={22} style={{borderRadius:"50%",objectFit:"cover",border:`1px solid ${C.border}`}}/>}
              <span style={{fontFamily:"Orbitron,monospace",fontSize:8,letterSpacing:2,color:m.role==="user"?"rgba(0,245,255,0.35)":"rgba(191,0,255,0.35)"}}>
                {m.role==="user" ? "YOU" : `VINITRONX [${(m.model||"AI").toUpperCase()}]`}
              </span>
              {m.role==="user" && <Image src="/photo.webp" alt="" width={22} height={22} style={{borderRadius:"50%",objectFit:"cover",border:"1px solid rgba(0,245,255,0.35)"}}/>}
            </div>
            <div style={{maxWidth:"82%",padding:"13px 17px",fontSize:14,lineHeight:1.8,whiteSpace:"pre-wrap",wordBreak:"break-word",background:m.role==="user"?"rgba(0,245,255,0.06)":"rgba(4,12,32,0.9)",border:`1px solid ${m.role==="user"?"rgba(0,245,255,0.2)":"rgba(191,0,255,0.18)"}`,borderRadius:m.role==="user"?"14px 14px 2px 14px":"14px 14px 14px 2px",color:C.text,fontFamily:"Rajdhani,sans-serif",fontWeight:500}}>
              {m.content}
            </div>
          </div>
        ))}

        {loading && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"flex-start"}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
              <Image src="/logo.png" alt="" width={22} height={22} style={{borderRadius:"50%",objectFit:"cover",border:`1px solid ${C.border}`}}/>
              <span style={{fontFamily:"Orbitron,monospace",fontSize:8,letterSpacing:2,color:"rgba(191,0,255,0.35)"}}>VINITRONX [{model.toUpperCase()}]</span>
            </div>
            <div style={{padding:"13px 18px",background:"rgba(4,12,32,0.9)",border:"1px solid rgba(191,0,255,0.18)",borderRadius:"14px 14px 14px 2px",display:"flex",gap:6}}>
              {[0,160,320].map((d,i)=><div key={i} style={{width:7,height:7,borderRadius:"50%",background:C.cyan,animation:`tdot 1.2s ${d}ms infinite`}}/>)}
            </div>
          </div>
        )}
        <div ref={ref}/>
      </div>

      {/* Input */}
      <div style={{padding:"10px 16px 18px",background:"rgba(2,4,8,0.8)",backdropFilter:"blur(10px)",borderTop:`1px solid ${C.border}`}}>
        <div style={{display:"flex",gap:10,alignItems:"flex-end",background:"rgba(0,7,20,0.96)",border:`1px solid ${C.border}`,borderRadius:14,padding:"10px 14px"}}>
          <textarea rows={2} value={input}
            onChange={e=>setInput(e.target.value)}
            onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}}
            placeholder={`${cfg.tag} — sawaal likho... (Enter = send, Shift+Enter = new line)`}
            disabled={loading}
            style={{flex:1,background:"transparent",border:"none",outline:"none",color:C.text,fontSize:14,fontFamily:"Rajdhani,sans-serif",fontWeight:500,resize:"none",lineHeight:1.6}}
          />
          <button onClick={send} disabled={loading||!input.trim()} style={{background:(!loading&&input.trim())?"linear-gradient(135deg,#00f5ff,#bf00ff)":"rgba(255,255,255,0.04)",border:"none",color:(!loading&&input.trim())?"#000":"rgba(255,255,255,0.15)",fontFamily:"Orbitron,monospace",fontSize:10,fontWeight:700,letterSpacing:1.5,padding:"12px 20px",borderRadius:10,cursor:(!loading&&input.trim())?"pointer":"not-allowed",transition:"all 0.2s",whiteSpace:"nowrap"}}>
            {loading ? "···" : "SEND ▶"}
          </button>
        </div>
      </div>

    </div>
  )
}

// ── PAGE 3: FEATURES ──────────────────────────────────────────────────────
function FeaturesPage() {
  const [hov, setHov] = useState(null)
  return (
    <div style={{padding:"36px 18px 52px",maxWidth:860,margin:"0 auto",position:"relative",zIndex:1}}>

      <div style={{textAlign:"center",marginBottom:40}}>
        <p style={{fontFamily:"Orbitron,monospace",fontSize:10,color:C.purple,letterSpacing:5,marginBottom:8}}>PLATFORM CAPABILITIES</p>
        <h2 style={{fontFamily:"Orbitron,monospace",fontSize:"clamp(18px,4vw,28px)",fontWeight:900,color:"#fff",margin:"0 0 12px"}}>
          Everything to <span style={{color:C.cyan,textShadow:`0 0 20px ${C.cyan}`}}>Build & Earn</span>
        </h2>
        <p style={{fontSize:15,color:C.muted,maxWidth:500,margin:"0 auto",lineHeight:1.7,fontFamily:"Rajdhani,sans-serif",fontWeight:500}}>
          Claude, Gemini, speed, security — VINITRONX AI mein sab kuch hai jo tumhe chahiye AI se kamaane ke liye.
        </p>
      </div>

      {/* Feature Cards */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:14,marginBottom:44}}>
        {FEATURES.map((f,i)=>(
          <div key={i}
            onMouseEnter={()=>setHov(i)} onMouseLeave={()=>setHov(null)}
            style={{background:hov===i?`${f.color}0e`:C.card,border:`1px solid ${hov===i?f.color:"rgba(0,245,255,0.1)"}`,borderRadius:16,padding:"22px 20px",cursor:"default",boxShadow:hov===i?`0 0 28px ${f.color}28`:"none",transition:"all 0.25s",backdropFilter:"blur(14px)"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
              <span style={{fontSize:28}}>{f.icon}</span>
              <span style={{fontFamily:"Orbitron,monospace",fontSize:8,color:f.color,border:`1px solid ${f.color}44`,padding:"2px 8px",borderRadius:10,letterSpacing:1}}>{f.badge}</span>
            </div>
            <div style={{fontFamily:"Orbitron,monospace",fontSize:11,color:f.color,fontWeight:700,letterSpacing:1,marginBottom:8}}>{f.title}</div>
            <div style={{fontSize:13,color:C.muted,lineHeight:1.7,fontFamily:"Rajdhani,sans-serif",fontWeight:500}}>{f.desc}</div>
          </div>
        ))}
      </div>

      {/* Tech Stack */}
      <Card style={{padding:"28px 24px"}}>
        <h3 style={{fontFamily:"Orbitron,monospace",fontSize:11,color:C.green,letterSpacing:4,marginBottom:20,textAlign:"center"}}>[ TECH STACK ]</h3>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(135px,1fr))",gap:10}}>
          {TECHSTACK.map(([ic,name,col])=>(
            <div key={name} style={{display:"flex",alignItems:"center",gap:9,padding:"11px 13px",background:`${col}08`,border:`1px solid ${col}20`,borderRadius:10}}>
              <span style={{fontSize:17}}>{ic}</span>
              <span style={{fontFamily:"Orbitron,monospace",fontSize:9,color:col,letterSpacing:.5}}>{name}</span>
            </div>
          ))}
        </div>
      </Card>

    </div>
  )
}

// ── PAGE 4: ABOUT ────────────────────────────────────────────────────────
function AboutPage() {
  return (
    <div style={{padding:"30px 18px 52px",maxWidth:700,margin:"0 auto",position:"relative",zIndex:1}}>

      {/* Profile */}
      <Card style={{padding:"34px 26px",textAlign:"center",marginBottom:14}}>
        <div style={{position:"relative",display:"inline-block",marginBottom:20}}>
          <Image src="/photo.webp" alt="Vinit" width={112} height={112}
            style={{borderRadius:"50%",objectFit:"cover",border:`3px solid ${C.cyan}`,boxShadow:`0 0 34px rgba(0,245,255,0.48)`,animation:"pulse 3s ease-in-out infinite"}}/>
          <div style={{position:"absolute",bottom:6,right:6,width:17,height:17,borderRadius:"50%",background:C.green,border:`2px solid #020408`,boxShadow:`0 0 10px ${C.green}`}}/>
        </div>
        <h2 style={{fontFamily:"Orbitron,monospace",fontSize:"clamp(14px,3vw,20px)",color:C.cyan,fontWeight:900,letterSpacing:2,margin:"0 0 5px",textShadow:`0 0 18px ${C.cyan}`}}>
          VINIT VIJAY BHADKE
        </h2>
        <p style={{fontFamily:"Orbitron,monospace",fontSize:10,color:C.purple,letterSpacing:3,margin:"0 0 6px"}}>AI DEVELOPER · FREELANCER · FOUNDER</p>
        <p style={{fontFamily:"Orbitron,monospace",fontSize:10,color:`${C.green}cc`,letterSpacing:3,margin:"0 0 20px"}}>🇮🇳 Maharashtra, India</p>
        <p style={{fontSize:15,color:C.muted,lineHeight:1.8,maxWidth:460,margin:"0 auto",fontFamily:"Rajdhani,sans-serif",fontWeight:500}}>
          AI aur technology mera passion hai. VINITRONX AI mera dream project hai — ek aise platform jo India aur duniya ke logon ke liye AI ko accessible banaye. Build. Earn. Automate.
        </p>
      </Card>

      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10,marginBottom:14}}>
        {STATS.map(s=>(
          <Card key={s.lbl} style={{padding:"20px",textAlign:"center",border:"1px solid rgba(191,0,255,0.18)"}}>
            <div style={{fontFamily:"Orbitron,monospace",fontSize:26,fontWeight:900,background:"linear-gradient(135deg,#00f5ff,#bf00ff)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>{s.val}</div>
            <div style={{fontFamily:"Orbitron,monospace",fontSize:8,color:"rgba(255,255,255,0.28)",letterSpacing:2,marginTop:5}}>{s.lbl}</div>
          </Card>
        ))}
      </div>

      {/* Skills */}
      <Card style={{padding:"22px 20px",marginBottom:14,border:"1px solid rgba(191,0,255,0.16)"}}>
        <div style={{fontFamily:"Orbitron,monospace",fontSize:10,color:C.purple,letterSpacing:4,marginBottom:14}}>[ SKILLS ]</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
          {SKILLS.map(s=>(
            <span key={s} style={{padding:"5px 14px",background:"rgba(191,0,255,0.08)",border:"1px solid rgba(191,0,255,0.22)",borderRadius:20,fontFamily:"Orbitron,monospace",fontSize:9,color:"rgba(191,0,255,0.85)"}}>{s}</span>
          ))}
        </div>
      </Card>

      {/* Contact */}
      <Card style={{padding:"22px 20px",marginBottom:14,border:"1px solid rgba(0,255,136,0.15)"}}>
        <div style={{fontFamily:"Orbitron,monospace",fontSize:10,color:C.green,letterSpacing:4,marginBottom:14}}>[ CONTACT & INFO ]</div>
        {[
          ["📧","Email",    "vinitbhadke456@gmail.com"],
          ["💼","Freelancer","vinit0987"],
          ["🏪","Fiverr",   "vinverse_123"],
          ["🌐","Platform", "VINITRONX AI v1.0"],
          ["⚙️","Backend",  "FastAPI + Python"],
          ["🎨","Frontend", "Next.js + TailwindCSS"],
        ].map(([ic,k,v])=>(
          <div key={k} style={{display:"flex",gap:12,marginBottom:11,alignItems:"center"}}>
            <span style={{fontSize:14}}>{ic}</span>
            <span style={{fontFamily:"Orbitron,monospace",fontSize:8,color:"rgba(0,255,136,0.4)",minWidth:76,letterSpacing:1}}>{k}</span>
            <span style={{fontFamily:"Rajdhani,monospace",fontSize:13,color:"rgba(200,230,255,0.65)",fontWeight:500}}>{v}</span>
          </div>
        ))}
      </Card>

      {/* Logo footer */}
      <Card style={{padding:"24px",textAlign:"center"}}>
        <Image src="/logo.png" alt="VINITRONX" width={90} height={90} style={{objectFit:"contain",filter:"drop-shadow(0 0 20px rgba(0,245,255,0.45))"}}/>
        <p style={{fontFamily:"Orbitron,monospace",fontSize:8,color:"rgba(0,245,255,0.28)",letterSpacing:4,marginTop:10}}>BUILD. EARN. AUTOMATE WITH AI</p>
      </Card>

    </div>
  )
}

// ── MAIN ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("home")
  const PAGES = { home:<HomePage setTab={setTab}/>, chat:<ChatPage/>, features:<FeaturesPage/>, about:<AboutPage/> }

  return (
    <div style={{minHeight:"100vh",background:C.bg,color:C.text}}>
      <Bg/>
      <div style={{maxWidth:900,margin:"0 auto",position:"relative",zIndex:1}}>
        <TopNav tab={tab} setTab={setTab}/>
        <div style={{overflowY: tab==="chat" ? "hidden" : "auto"}}>
          {PAGES[tab]}
        </div>
      </div>
    </div>
  )
}
