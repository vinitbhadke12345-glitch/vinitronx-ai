import "./globals.css"

export const metadata = {
  title: "VINITRONX AI — Build. Earn. Automate with AI",
  description: "India's #1 All-in-One AI Platform powered by Claude & Gemini. Built by Vinit Vijay Bhadke.",
  icons: { icon: "/logo.png" },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;700;900&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
